(function( $ ){

	"use strict";
	
	

} )( jQuery );

